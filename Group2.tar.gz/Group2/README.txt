Gregory Teh-Kai:
Command handling, error handling, socket implementation, bind, connect, myip, myport, list, testing, incoming conenection handling

Brandon Umansky:
Command handling, error handling, socket implementation, terminate, send, help, exit, select, testing, disconnect handling

Dependencies:
base-cygwin
cygwin
cygwin-develop

Build:
gcc chat.c -o chat

Run:
./chat <port#>

